#!/usr/bin/env python3
"""Repair stale UI layers and guarantee the Welcome CTA remains tappable."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "www" / "index.html"
text = INDEX.read_text(encoding="utf-8")

STYLE_MARKER = "/* ResuMate interaction recovery: prevent stale hidden modal layers from covering UI. */"
SCRIPT_MARKER = "window.__ResuMateInteractionRecoveryInstalledV3"

STYLE = r'''
/* ResuMate interaction recovery: prevent stale hidden modal layers from covering UI. */
.overlay:not(.show),
.modal:not(.show),
.dialog:not(.show),
.drawer:not(.show),
.sheet:not(.show),
.overlay[aria-hidden="true"],
.modal[aria-hidden="true"],
.dialog[aria-hidden="true"],
.drawer[aria-hidden="true"],
.sheet[aria-hidden="true"] {
  display: none !important;
  visibility: hidden !important;
}
/* The Welcome screen is the startup interaction surface. Keep it above every
   compatibility/export layer and make the two CTAs independently tappable. */
#welcome.show {
  pointer-events: auto !important;
  z-index: 2147483647 !important;
  position: fixed !important;
  inset: 0 !important;
  touch-action: manipulation !important;
}
#welcome.show .overlay-body,
#welcome.show button,
#welcome.show a,
#welcome.show input,
#welcome.show [role="button"] {
  pointer-events: auto !important;
  touch-action: manipulation !important;
}
#welcome.show button {
  -webkit-user-select: none !important;
  user-select: none !important;
  -webkit-tap-highlight-color: transparent !important;
}
'''

SCRIPT = r'''
<script>
(function(){
  'use strict';
  if(window.__ResuMateInteractionRecoveryInstalledV3) return;
  window.__ResuMateInteractionRecoveryInstalledV3=true;

  const selectors='.overlay,.modal,.dialog,.drawer,.sheet';
  function hideStaleLayers(root){
    (root || document).querySelectorAll(selectors).forEach(function(el){
      if(el.id === 'welcome') return;
      if(el.classList.contains('show') && el.getAttribute('aria-hidden') !== 'true') return;
      var s=getComputedStyle(el), r=el.getBoundingClientRect();
      var large=r.width >= window.innerWidth*0.85 && r.height >= window.innerHeight*0.65;
      var overlayLike=s.position==='fixed' || s.position==='absolute' || s.position==='sticky';
      if(overlayLike && large){
        el.style.display='none';
        el.style.visibility='hidden';
        el.style.pointerEvents='none';
      }
    });
  }

  function welcomeVisible(){
    var w=document.getElementById('welcome');
    return !!(w && w.classList.contains('show') && getComputedStyle(w).display!=='none' && getComputedStyle(w).visibility!=='hidden');
  }

  function pointInRect(x,y,r){ return x>=r.left && x<=r.right && y>=r.top && y<=r.bottom; }

  function welcomeControlAt(x,y){
    var w=document.getElementById('welcome');
    if(!w) return null;
    var controls=w.querySelectorAll('button,a,[role="button"],input[type="button"],input[type="submit"],input');
    for(var i=0;i<controls.length;i++){
      var c=controls[i], r=c.getBoundingClientRect(), s=getComputedStyle(c);
      if(s.display!=='none' && s.visibility!=='hidden' && r.width>0 && r.height>0 && pointInRect(x,y,r)) return c;
    }
    return null;
  }

  function fallbackHome(){
    var w=document.getElementById('welcome');
    if(!w || !welcomeVisible()) return;
    try { if(typeof window.go==='function'){ window.go('home'); return true; } } catch(e){}
    try { if(typeof window.navigate==='function'){ window.navigate('home'); return true; } } catch(e){}
    try { if(typeof window.showView==='function'){ window.showView('home'); return true; } } catch(e){}
    var home=document.getElementById('home') || document.querySelector('.view[data-view="home"]');
    if(home){
      w.classList.remove('show');
      w.setAttribute('aria-hidden','true');
      home.classList.add('active','show');
      home.removeAttribute('aria-hidden');
      return true;
    }
    return false;
  }

  function activateWelcomeControl(control){
    if(!control || !welcomeVisible()) return false;
    try {
      if(control.id === 'welcomeName') { control.focus(); return true; }
      if(control.classList.contains('btn-pay')) {
        if(typeof window.completeOnboarding==='function') { window.completeOnboarding(); return true; }
      }
      if(control.classList.contains('btn-outline')) {
        if(typeof window.skipOnboarding==='function') { window.skipOnboarding(); return true; }
      }
      control.click();
      return true;
    } catch(err) {
      return false;
    }
  }

  function recoverWelcomeTap(e){
    if(!welcomeVisible()) return;
    var x=e.clientX, y=e.clientY;
    if((x==null || y==null) && e.changedTouches && e.changedTouches[0]){ x=e.changedTouches[0].clientX; y=e.changedTouches[0].clientY; }
    if(x==null || y==null) return;
    var w=document.getElementById('welcome'), r=w.getBoundingClientRect();
    if(!pointInRect(x,y,r)) return;
    var control=welcomeControlAt(x,y);
    if(!control) return;
    if(e.type==='touchstart' && control.id==='welcomeName'){
      try { control.focus(); } catch(_){}
      return;
    }
    if(e.type==='touchend' || e.type==='pointerup'){
      if(e.cancelable) e.preventDefault();
      e.stopPropagation();
      if(activateWelcomeControl(control)){
        setTimeout(function(){ if(welcomeVisible() && control.tagName==='BUTTON') fallbackHome(); },120);
      }
    } else if(e.type==='click' && e.target !== control && !control.contains(e.target)){
      e.preventDefault();
      e.stopPropagation();
      if(activateWelcomeControl(control)) setTimeout(function(){ if(welcomeVisible()) fallbackHome(); },120);
    }
  }

  function bindWelcomeDirect(){
    var w=document.getElementById('welcome');
    if(!w || w.dataset.touchRecoveryBound==='1') return;
    w.dataset.touchRecoveryBound='1';
    w.addEventListener('touchstart',function(e){ recoverWelcomeTap(e); },{capture:true,passive:false});
    w.addEventListener('touchend',function(e){ recoverWelcomeTap(e); },{capture:true,passive:false});
    w.addEventListener('click',function(e){
      if(e.target && (e.target.closest('button,a,[role="button"]'))){ return; }
      recoverWelcomeTap(e);
    },true);
  }

  function start(){
    hideStaleLayers(document);
    bindWelcomeDirect();
    document.addEventListener('pointerdown',recoverWelcomeTap,true);
    document.addEventListener('touchstart',recoverWelcomeTap,true);
    document.addEventListener('pointerup',recoverWelcomeTap,true);
    document.addEventListener('touchend',recoverWelcomeTap,true);
    document.addEventListener('click',recoverWelcomeTap,true);
    var observer=new MutationObserver(function(records){
      var changed=false;
      for(var i=0;i<records.length;i++){
        if(records[i].type==='childList' || records[i].attributeName==='class' || records[i].attributeName==='style' || records[i].attributeName==='aria-hidden'){ changed=true; break; }
      }
      if(changed){ hideStaleLayers(document); bindWelcomeDirect(); }
    });
    observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','aria-hidden']});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();
</script>
'''

# Replace any older interaction-recovery patch, so repeated builds are deterministic.
if STYLE_MARKER in text:
    import re
    text = re.sub(r'/\* ResuMate interaction recovery: prevent stale hidden modal layers from covering UI\. \*/.*?(?=</style>)', STYLE.rstrip() + '\n', text, count=1, flags=re.S)
else:
    text = text.replace('</style>', STYLE + '\n</style>', 1)

# Remove all previous recovery script variants before inserting V3.
import re
text = re.sub(r'<script>\s*\(function\(\)\{\s*[\'\"]use strict[\'\"];\s*if\(window\.__ResuMateInteractionRecoveryInstalled(?:V2|V3)\).*?</script>\s*', '', text, count=1, flags=re.S)
text = text.replace('</body>', SCRIPT + '\n</body>', 1)

INDEX.write_text(text, encoding='utf-8')
print('Applied Welcome CTA interaction recovery V3')
