#!/usr/bin/env python3
"""Guarantee that tap-driven navigation activates the requested view.

Some Android WebView builds can execute the inline navigation handler but leave
an old view visually active when a renderer throws or a compatibility layer
runs immediately afterwards. Keep the approved UI and recover only the view
state after the existing navigation function has run.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "www" / "index.html"
text = INDEX.read_text(encoding="utf-8")

MARKER = "ResuMate navigation recovery v1"
SCRIPT = r'''
<script>
(function(){
  'use strict';
  if(window.__ResuMateNavigationRecoveryV1) return;
  window.__ResuMateNavigationRecoveryV1=true;

  function forceView(name){
    if(!name) return false;
    var target=document.getElementById(String(name));
    if(!target || !target.classList.contains('view')) return false;
    document.querySelectorAll('.view').forEach(function(v){
      v.classList.toggle('active', v===target);
    });
    document.querySelectorAll('.nav button').forEach(function(b){b.classList.remove('active');});
    var nav=document.getElementById('nav-'+name);
    if(nav) nav.classList.add('active');
    var tag=document.getElementById('headerTag');
    if(tag) tag.textContent=name==='score'?'Resume Score':name.charAt(0).toUpperCase()+name.slice(1);
    var content=document.getElementById('content');
    if(content) content.scrollTop=0;
    return true;
  }

  function install(){
    if(typeof window.go !== 'function') return;
    var original=window.go;
    if(original.__resumateRecoveryWrapped) return;
    function recoveredGo(name, fromBack){
      var result;
      try { result=original.call(this,name,fromBack); }
      catch(err){ console.error('ResuMate navigation error:',err); }
      forceView(name);
      setTimeout(function(){forceView(name);},0);
      setTimeout(function(){forceView(name);},80);
      return result;
    }
    recoveredGo.__resumateRecoveryWrapped=true;
    recoveredGo.__originalGo=original;
    window.go=recoveredGo;
  }

  function start(){
    install();
    var observer=new MutationObserver(function(){ install(); });
    observer.observe(document.documentElement,{childList:true,subtree:true});
    document.addEventListener('click',function(e){
      var el=e.target && e.target.closest ? e.target.closest('[onclick]') : null;
      if(!el) return;
      var code=el.getAttribute('onclick') || '';
      var match=code.match(/window\.go\(\s*['\"]([A-Za-z0-9_-]+)['\"]/);
      if(match && typeof window.go==='function'){
        setTimeout(function(){forceView(match[1]);},0);
      }
    },true);
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();
</script>
'''.replace("'use strict';", "'use strict'; /* " + MARKER + " */", 1)

# Replace any previous version deterministically.
import re
text = re.sub(r'<script>\s*\(function\(\)\{\s*[\'\"]use strict[\'\"];\s*/\* ResuMate navigation recovery v1 \*/.*?</script>\s*', '', text, count=1, flags=re.S)
text = text.replace('</body>', SCRIPT + '\n</body>', 1)
INDEX.write_text(text, encoding='utf-8')
print('Applied ResuMate navigation recovery v1')
