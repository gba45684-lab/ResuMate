#!/usr/bin/env python3
"""No-op: app-source.html already has the real, animated Welcome screen.

History: this script used to INJECT a second, simplified <div id="welcome">
right after <body>. app-source.html has always had its own native welcome
overlay further down the page (in the "OVERLAYS" section) built on the
shared `.overlay` class -- the same one used by the Premium/AI modals --
which already animates in with a slide-up + fade (see `.overlay` /
`.overlay.show` in the CSS) and is fully wired to window.completeOnboarding()
/ window.skipOnboarding().

Because HTML just returns the FIRST element with a given id,
document.getElementById('welcome') was resolving to this script's injected
copy instead -- silently shadowing the real, better, already-animated
overlay with a plainer stand-in that had no relation to the app's state
management (name personalization, resume renaming, etc.), and that also
raced against a legacy click-recovery fallback (patch-interaction-
recovery.py), causing the welcome screen to sometimes snap shut instead of
animating.

The underlying reason the native overlay ever looked "broken" was a
completely unrelated bug: a corrupted regex literal in finalize-export-ui.py
was throwing a SyntaxError that aborted the entire main app script, so
window.completeOnboarding/skipOnboarding (and every other handler) never
got defined. That root cause is fixed now, so the native overlay's buttons
work correctly on their own. This script is kept as a no-op (rather than
removed from the pipeline) so scripts/build-web.py's required-file check
still passes.
"""
